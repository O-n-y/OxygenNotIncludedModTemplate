﻿using System;
using System.Reflection;
using Harmony;
using OxygenNotIncluded.Mods.SharedLib;
using UnityEngine;

namespace OxygenNotIncluded.Mods.$safeprojectname$
{
	public class Loader : LoaderBase
	{
	}
}
